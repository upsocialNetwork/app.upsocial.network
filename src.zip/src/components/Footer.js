


const Footer = (props) => {

    return null
}

export default Footer;