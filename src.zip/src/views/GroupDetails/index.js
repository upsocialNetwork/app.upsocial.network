import { connect } from 'react-redux';

import GroupDetails from './GroupDetails';

const mapStateToProps = (state) => {
	return {};
};

const mapDispatchToProps = (dispatch) => {
	return {
	};
};


export default connect(
	mapStateToProps,
	mapDispatchToProps
)(GroupDetails);
