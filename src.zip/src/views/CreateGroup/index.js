import { connect } from 'react-redux';

import CreateGroup from './CreateGroup';

const mapStateToProps = (state) => {
	return {};
};

const mapDispatchToProps = (dispatch) => {
	return {
	};
};


export default connect(
	mapStateToProps,
	mapDispatchToProps
)(CreateGroup);
