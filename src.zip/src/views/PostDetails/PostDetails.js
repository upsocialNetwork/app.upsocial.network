import React, { useEffect, useState } from 'react';

import ReactQuill from 'react-quill'; // ES6
import 'react-quill/dist/quill.snow.css';
import Session from '../../utils/session';
import { useHistory } from 'react-router-dom';
import { useLocation } from 'react-router-dom'
const PostDetails = (props) => {

    const location = useLocation();

    const history = useHistory();
    let element = props.postData;
    let [userData, setUserData] = useState();


    useEffect(() => {
        let user = Session.getSessionData();
        if (user == null) {

        }
        else {

            setUserData(user);
            console.log(location);
            console.log(location.state.PostDetails);
        }

    }, []);

    const navigate = (event) => {
        event.preventDefault()
    }


    const pageDetails = (event) => {
        event.preventDefault();
        console.log("calling page redirect");
        history.push("/post-details");
    }

    const editPost = (event, postid) => {
        event.preventDefault();
        console.log(postid);
       /*  history.push({
            pathname: '/edit-post',
            search: '?id=' + postid + '',
            state: { postid: postid }
        }) */;

    }


    return (<>post details</>)
}
export default PostDetails;