import { connect } from 'react-redux';

import CreateGroupPost from './CreateGroupPost';
const mapStateToProps = (state) => {
	return {};
};

const mapDispatchToProps = (dispatch) => {
	return {
	};
};


export default connect(
	mapStateToProps,
	mapDispatchToProps
)(CreateGroupPost);
