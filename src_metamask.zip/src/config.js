/* let appConfig = {
  'APP_ENV': 'Stage',
  'APP_PUBLIC_URL': '',
  'API_URL': 'https://api-sit.upsocial.network:8443/Upsocial/ipfsservice/api/v1/',
  'API_KEY': '',
  'DATA_ENCRYPT_KEY': 'B86897CA1FA567B7F7LL2975C3AB5A09CE1C9F9CB29CE4390CB9FE9CED847AC8',
  'CHOKIDAR_USEPOLLING': true
} */

/* let appConfig = {
  'APP_ENV': 'Stage',
  'APP_PUBLIC_URL': '',
  'API_URL': 'https://api.upsocial.network:8443/Upsocial/ipfsservice/api/v1/',
  'API_KEY': '',
  'DATA_ENCRYPT_KEY': 'B86897CA1FA567B7F7LL2975C3AB5A09CE1C9F9CB29CE4390CB9FE9CED847AC8',
  'CHOKIDAR_USEPOLLING': true
} */

let appConfig = {
  'APP_ENV': 'Local',
  'APP_PUBLIC_URL': '',
  'API_URL': 'http://localhost:8433/Upsocial/ipfsservice/api/v1/',
  'API_KEY': 'fdsf435r743n9',
  'DATA_ENCRYPT_KEY': 'B86897CA1FA567B7F7LL2975C3AB5A09CE1C9F9CB29CE4390CB9FE9CED847AC8',
  'CHOKIDAR_USEPOLLING': true
}
export default appConfig;