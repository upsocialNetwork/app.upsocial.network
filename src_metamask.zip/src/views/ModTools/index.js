import { connect } from 'react-redux';
import ModTools from './ModTools';

const mapStateToProps = (state) => {
	return {};
};

const mapDispatchToProps = (dispatch) => {
	return {
	};
};


export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ModTools);
